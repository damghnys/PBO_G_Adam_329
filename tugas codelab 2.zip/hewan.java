public class hewan {
    String NamaHewan;
    String Jenis;
    String Suara;

    void tampilkaninfo(){
        System.out.println("Nama Hewan: " + NamaHewan);
        System.out.println("Jenis Hewan: " + Jenis);
        System.out.println("Suara Hewan: " + Suara );
        System.out.println();

        System.out.println(" Adam Al Ghonniy Soetejoe ");
        System.out.println();
    }
}