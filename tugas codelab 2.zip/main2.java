public class main2 {
    public static void main(String[] args) {
        hewan hewan1 = new hewan();
        hewan hewan2 = new hewan();

        hewan1.NamaHewan = "Kucing";
        hewan2.NamaHewan = "Anjing";

        hewan1.Jenis = "Mamalia";
        hewan2.Jenis = "Mamalia";

        hewan1.Suara = "nyann~~";
        hewan2.Suara = "Wooff-Wooff!!";

        hewan1.tampilkaninfo();
        hewan2.tampilkaninfo();

    }
}